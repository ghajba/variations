variations
==========

Repository for a project with many variations

In the history folder you find a compresses (mostly .rar) version of all steps done in this project as a reference to http://hahamo.wordpress.com/category/software-development/variations/

Travis.CI: https://travis-ci.org/ghajba/variations

UPDATE:
-------------
After adding the Hibernate dependency I skipped the versioning with .rar files. Although I keep the versioning, at least in my blog.