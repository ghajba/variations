package biz.hahamo.dev.variations.controller.repository;

/**
 * Marker interface for data access within the database -- used with {@link GenericRepository}
 * 
 * @author GHajba
 *
 */
public interface PersistenceQuery
{

}
